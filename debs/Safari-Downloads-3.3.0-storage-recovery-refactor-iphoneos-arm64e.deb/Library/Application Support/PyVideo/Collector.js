(() => {
  'use strict';
  const key = '__pyvideoCollector_v1';
  if (globalThis[key]) { globalThis[key].scan(); return; }
  const documentID = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const ids = new WeakMap(), previews = new WeakMap(), resources = new Map();
  let sequence = 0, timer = null, running = false, active = false, lastMessage = '', lastURL = location.href, resourceStart = 0;
  const http = value => {
    if (typeof value !== 'string' || !value.trim() || value.length > 16384) return '';
    try { const u = new URL(value, document.baseURI); return /^https?:$/.test(u.protocol) ? u.href : ''; }
    catch (_) { return ''; }
  };
  const height = element => {
    const label = ['data-height', 'data-res', 'res', 'size', 'label', 'data-quality']
      .map(a => element.getAttribute(a) || '').join(' ');
    const match = label.match(/(?:^|\D)(240|360|480|540|576|720|1080|1440|2160|4320)(?:p|\D|$)/i);
    return match ? Number(match[1]) : 0;
  };
  const navigation = () => {
    if (lastURL !== location.href) { lastURL = location.href; resourceStart = performance.now(); resources.clear(); }
  };
  const rememberResources = entries => {
    navigation();
    for (const entry of entries) {
      if ((entry.startTime || 0) < resourceStart || !/\.(mp4|m4v|mov|m3u8)(?:[?#]|$)/i.test(entry.name)) continue;
      const url = http(entry.name);
      if (url) resources.set(url, true);
    }
    while (resources.size > 20) resources.delete(resources.keys().next().value);
  };
  const scan = (force = false) => {
    if (timer !== null) { clearTimeout(timer); timer = null; }
    if (!running) return;
    navigation();
    // The Resource Timing fallback is used on explicit refresh, never on a timer.
    if (force) rememberResources(performance.getEntriesByType('resource'));
    const videos = [];
    for (const v of [...document.querySelectorAll('video')].slice(0, 40)) {
      if (!ids.has(v)) ids.set(v, ++sequence);
      const sources = new Map();
      const add = (value, h = 0, type = '') => {
        const url = value && http(value);
        if (!url) return;
        const old = sources.get(url);
        if (!old || old.height < h) sources.set(url, {url, height: h, type: String(type || '').slice(0, 100)});
      };
      add(v.currentSrc, v.videoHeight || 0, v.getAttribute('type'));
      add(v.getAttribute('src'), height(v), v.getAttribute('type'));
      for (const s of [...v.querySelectorAll('source')].slice(0, 16)) add(s.getAttribute('src'), height(s), s.type);
      const poster = http(v.poster || '');
      const sourceKey = String(v.currentSrc || v.src || '');
      let preview = previews.get(v);
      if (preview && preview.source !== sourceKey) { previews.delete(v); preview = null; }
      if (active && !poster && !preview && v.readyState >= 2 && v.videoWidth > 0) {
        preview = {source: sourceKey, data: ''}; previews.set(v, preview);
        try {
          const canvas = document.createElement('canvas');
          canvas.width = 200; canvas.height = Math.min(300, Math.max(1, Math.round(200 * v.videoHeight / v.videoWidth)));
          canvas.getContext('2d').drawImage(v, 0, 0, canvas.width, canvas.height);
          preview.data = canvas.toDataURL('image/jpeg', 0.55);
        } catch (_) { /* Cache cross-origin failures until the source changes. */ }
      }
      const list = [...sources.values()].slice(0, 16);
      if (list.length || sourceKey.startsWith('blob:')) videos.push({
        key: `${documentID}-${ids.get(v)}`, title: (v.getAttribute('aria-label') || v.title || document.title || '视频').slice(0, 180),
        sources: list, poster, thumbnail: preview?.data || '', blob: !list.length,
        duration: Number.isFinite(v.duration) ? v.duration : 0
      });
    }
    const seen = new Set(videos.flatMap(v => v.sources.map(s => s.url)));
    for (const url of resources.keys()) if (!seen.has(url)) videos.push({
      key: `${documentID}-resource-${url}`, title: (document.title || '页面视频资源').slice(0, 180),
      sources: [{url, height: 0, type: ''}], poster: '', thumbnail: '', blob: false, duration: 0
    });
    const message = {version: 1, documentID, page: location.href.slice(0, 16384), active, videos};
    const signature = JSON.stringify(message);
    if (!force && signature === lastMessage) return;
    try { globalThis.webkit.messageHandlers.pyvideo_v1.postMessage(message); lastMessage = signature; } catch (_) {}
  };
  const schedule = () => { if (running && timer === null) timer = setTimeout(scan, 350); };
  const relevant = n => n.nodeType === 1 && (n.matches('video,source,iframe') || n.querySelector('video,source,iframe'));
  const observer = new MutationObserver(records => {
    if (records.some(r => r.type === 'attributes'
      ? r.target.matches('video,source')
      : [...r.addedNodes, ...r.removedNodes].some(relevant))) schedule();
  });
  let resourceObserver;
  try {
    resourceObserver = new PerformanceObserver(list => {
      const before = [...resources.keys()].join('\n');
      rememberResources(list.getEntries());
      if (before !== [...resources.keys()].join('\n')) schedule();
    });
  } catch (_) {}
  const start = () => {
    if (running || document.hidden) return;
    running = true;
    observer.observe(document, {subtree: true, childList: true, attributes: true,
      attributeFilter: ['src', 'poster', 'data-height', 'data-res', 'res', 'size', 'label', 'data-quality']});
    try { resourceObserver?.observe({type: 'resource', buffered: true}); } catch (_) {}
    scan(true);
  };
  const stop = () => {
    running = active = false; observer.disconnect(); resourceObserver?.disconnect();
    if (timer !== null) clearTimeout(timer); timer = null;
  };
  for (const name of ['loadedmetadata', 'loadeddata', 'loadstart', 'playing', 'emptied']) document.addEventListener(name, event => {
    if (event.target?.matches('video,source')) schedule();
  }, true);
  document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());
  addEventListener('pagehide', stop);
  addEventListener('pageshow', start);
  globalThis[key] = {scan: () => scan(true), stop, setActive: (value, force = false) => {
    const changed = active !== !!value; active = !!value;
    if (active && (changed || force)) scan(true);
  }};
  start();
})();
